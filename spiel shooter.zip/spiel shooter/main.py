import pygame
import sys
import random
import os

# -------------------------------------------------------------------
#  Konfigurationen
# -------------------------------------------------------------------
WIDTH, HEIGHT = 800, 600
FPS = 60

# Sprite-Größen (in Pixel)
PLAYER_SIZE = 64
ENEMY_SIZE = 64
BULLET_SIZE = 16
POWERUP_SIZE = 32

# Geschwindigkeiten
PLAYER_SPEED = 5
BULLET_SPEED = 10
ENEMY_MIN_SPEED = 3
ENEMY_MAX_SPEED = 6
POWERUP_SPEED = 3

# Farben
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Power-Up-Wahrscheinlichkeit beim Gegner-Tod
POWERUP_CHANCE = 0.10  # 10 %

# LEBEN
PLAYER_LIVES = 3

# -------------------------------------------------------------------
#  Helfer-Funktion: Lade alle Bilder aus assets/images/
# -------------------------------------------------------------------
def load_image(name, subfolder="images", size=None, colorkey=None):
    fullname = os.path.join("assets", subfolder, name)
    try:
        image = pygame.image.load(fullname).convert_alpha()
    except pygame.error as message:
        print(f"Kann Bild nicht laden: {fullname}")
        raise SystemExit(message)
    if size is not None:
        image = pygame.transform.scale(image, size)
    if colorkey is not None:
        image.set_colorkey(colorkey)
    return image

# -------------------------------------------------------------------
#  Helfer-Funktion: Lade alle Sounds aus assets/sounds/
#  (wird zwar geladen, aber nie abgespielt)
# -------------------------------------------------------------------
def load_sound(name, subfolder="sounds"):
    fullname = os.path.join("assets", subfolder, name)
    try:
        sound = pygame.mixer.Sound(fullname)
    except pygame.error as message:
        print(f"Kann Sound nicht laden: {fullname}")
        raise SystemExit(message)
    return sound

# -------------------------------------------------------------------
#  Klasse: Spieler-Raumschiff
# -------------------------------------------------------------------
class Player(pygame.sprite.Sprite):
    def __init__(self, assets):
        super().__init__()
        # Grafik und Rechteck
        self.image = assets["player_img"]
        self.rect = self.image.get_rect()
        # Starte links Mitte
        self.rect.center = (WIDTH * 0.1, HEIGHT // 2)
        self.speed = PLAYER_SPEED
        self.lives = PLAYER_LIVES

        # Schussverzögerung (ms)
        self.shoot_delay = 250
        self.last_shot = pygame.time.get_ticks()

        # Sounds (werden nicht abgespielt)
        self.shoot_sound = assets["shoot_sound"]

    def update(self):
        # Bewegung aus get_pressed()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            self.rect.y -= self.speed
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            self.rect.y += self.speed

        # Bildschirmränder
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT

    def shoot(self, bullet_group, assets):
        now = pygame.time.get_ticks()
        if now - self.last_shot > self.shoot_delay:
            self.last_shot = now
            bullet = BulletPlayer(self.rect.right, self.rect.centery, assets)
            bullet_group.add(bullet)
            assets["all_sprites"].add(bullet)
            # self.shoot_sound.play()  # Soundeffekt vorerst deaktiviert

# -------------------------------------------------------------------
#  Klasse: Spieler-Schuss (Bullet)
# -------------------------------------------------------------------
class BulletPlayer(pygame.sprite.Sprite):
    def __init__(self, x, y, assets):
        super().__init__()
        self.image = assets["bullet_player"]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = BULLET_SPEED

    def update(self):
        self.rect.x += self.speed
        # Löschen, sobald aus dem Bildschirm
        if self.rect.left > WIDTH:
            self.kill()

# -------------------------------------------------------------------
#  Klasse: Gegner
# -------------------------------------------------------------------
class Enemy(pygame.sprite.Sprite):
    def __init__(self, assets):
        super().__init__()
        self.image = assets["enemy1"]
        self.rect = self.image.get_rect()
        # Starte rechts außerhalb: zufällige Y-Position
        self.rect.x = WIDTH + random.randint(20, 100)
        self.rect.y = random.randint(50, HEIGHT - 50)
        self.speed_x = random.randint(ENEMY_MIN_SPEED, ENEMY_MAX_SPEED)

        # Schussverhalten (optional: Gegner schießt zurück)
        self.shoot_delay = random.randint(1000, 2000)
        self.last_shot = pygame.time.get_ticks()
        self.bullet_enemy_image = assets["bullet_enemy"]
        self.all_sprites = assets["all_sprites"]
        self.enemy_bullets = assets["enemy_bullets"]

    def update(self):
        # Nach links bewegen
        self.rect.x -= self.speed_x
        if self.rect.right < 0:
            self.kill()

        # Optional: Gegner schießt in Richtung Player (wenn aktiviert)
        now = pygame.time.get_ticks()
        if now - self.last_shot > self.shoot_delay:
            self.last_shot = now
            bullet = BulletEnemy(self.rect.left, self.rect.centery, self.bullet_enemy_image)
            self.enemy_bullets.add(bullet)
            self.all_sprites.add(bullet)

# -------------------------------------------------------------------
#  Klasse: Gegner-Bullet
# -------------------------------------------------------------------
class BulletEnemy(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = BULLET_SPEED - 3  # Etwas langsamer als Spieler-Bullet

    def update(self):
        self.rect.x -= self.speed
        if self.rect.right < 0:
            self.kill()

# -------------------------------------------------------------------
#  Klasse: Power-Up
# -------------------------------------------------------------------
class PowerUp(pygame.sprite.Sprite):
    def __init__(self, x, y, kind, assets):
        super().__init__()
        self.kind = kind  # "shield" oder "weapon"
        if self.kind == "shield":
            self.image = assets["powerup_shield"]
        else:
            self.image = assets["powerup_weapon"]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = POWERUP_SPEED
        self.pickup_sound = assets["powerup_sound"]

    def update(self):
        self.rect.x -= self.speed
        if self.rect.right < 0:
            self.kill()

    def apply(self, player):
        # Wende den Effekt auf den Spieler an
        # self.pickup_sound.play()  # Soundeffekt vorerst deaktiviert
        if self.kind == "weapon":
            # Schnellere Schüsse: maximal 100 ms Cooldown
            player.shoot_delay = max(100, player.shoot_delay - 50)
        else:
            # Schild: +1 Leben
            player.lives += 1
        self.kill()

# -------------------------------------------------------------------
#  Klasse: Explosion (Animation)
# -------------------------------------------------------------------
class Explosion(pygame.sprite.Sprite):
    def __init__(self, center, explosion_sprites, all_sprites_group):
        super().__init__()
        self.explosion_sprites = explosion_sprites
        self.frame = 0
        if self.explosion_sprites:
            self.image = self.explosion_sprites[self.frame]
        else:
            # Wenn keine Frames vorhanden, benutze eine leere Fläche
            self.image = pygame.Surface((0, 0))
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.last_update = pygame.time.get_ticks()
        self.frame_rate = 50  # ms pro Frame
        all_sprites_group.add(self)

    def update(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > self.frame_rate:
            self.last_update = now
            self.frame += 1
            if self.frame == len(self.explosion_sprites):
                self.kill()
            else:
                self.image = self.explosion_sprites[self.frame]
                self.rect = self.image.get_rect(center=self.rect.center)

# -------------------------------------------------------------------
#  Hauptfunktion
# -------------------------------------------------------------------
def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Space Shooter")
    clock = pygame.time.Clock()

    # -------------------------------------------------------------------
    #  Assets laden
    # -------------------------------------------------------------------
    assets = {}
    assets["background"] = load_image("background.png", size=(1600, HEIGHT))
    assets["player_img"] = load_image("player.png", size=(PLAYER_SIZE, PLAYER_SIZE))
    assets["enemy1"] = load_image("enemy1.png", size=(ENEMY_SIZE, ENEMY_SIZE))
    assets["bullet_player"] = load_image("bullet_player.png", size=(BULLET_SIZE, BULLET_SIZE))
    assets["bullet_enemy"] = load_image("bullet_enemy.png", size=(BULLET_SIZE, BULLET_SIZE))
    assets["powerup_shield"] = load_image("powerup_shield.png", size=(POWERUP_SIZE, POWERUP_SIZE))
    assets["powerup_weapon"] = load_image("powerup_weapon.png", size=(POWERUP_SIZE, POWERUP_SIZE))

    # Explosion-Sprites laden (wenn du nichts hast, belasse es leer)
    explosion_sprites = []
    # Wenn du später Explosion-Frames verwenden willst, entferne das Kommentar hier:
    # for i in range(6):  # z. B. 6 Frames: frame_0.png bis frame_5.png
    #     img = load_image(f"frame_{i}.png", subfolder="images/explosion", size=(ENEMY_SIZE, ENEMY_SIZE))
    #     explosion_sprites.append(img)
    assets["explosion_sprites"] = explosion_sprites

    # -------------------------------------------------------------------
    #  Sounds  (alles auskommentiert – wird nicht abgespielt)
    # -------------------------------------------------------------------
    # pygame.mixer.music.load(os.path.join("assets", "sounds", "bg_music.ogg"))
    # pygame.mixer.music.set_volume(0.5)
    # pygame.mixer.music.play(-1)  # unendlich loopen

    assets["shoot_sound"] = load_sound("shoot.wav")
    assets["explosion_sound"] = load_sound("explosion.wav")
    assets["powerup_sound"] = load_sound("powerup.wav")
    assets["gameover_sound"] = load_sound("gameover.wav")

    # ----------------------------------------------------------------------------
    #  Gruppen für Sprites
    # ----------------------------------------------------------------------------
    all_sprites = pygame.sprite.Group()
    player_group = pygame.sprite.Group()
    bullet_group = pygame.sprite.Group()
    enemy_group = pygame.sprite.Group()
    enemy_bullets = pygame.sprite.Group()
    powerup_group = pygame.sprite.Group()
    explosion_group = pygame.sprite.Group()

    # Assets-Dictionary um Referenzen zu teilen
    assets["all_sprites"] = all_sprites
    assets["enemy_bullets"] = enemy_bullets

    # -------------------------------------------------------------------
    #  Spieler erzeugen
    # -------------------------------------------------------------------
    player = Player(assets)
    all_sprites.add(player)
    player_group.add(player)

    # -------------------------------------------------------------------
    #  Gegner-Spawn-Event
    # -------------------------------------------------------------------
    SPAWN_EVENT = pygame.USEREVENT + 1
    pygame.time.set_timer(SPAWN_EVENT, 1500)  # Alle 1,5 Sekunden ein neuer Gegner

    # -------------------------------------------------------------------
    #  Hintergrund-Scrolling vorbereiten
    # -------------------------------------------------------------------
    bg_img = assets["background"]
    bg_width = bg_img.get_width()
    x_bg = 0

    # -------------------------------------------------------------------
    #  Score und Highscore
    # -------------------------------------------------------------------
    score = 0
    highscore_file = "highscores.txt"
    highscores = []
    if os.path.isfile(highscore_file):
        with open(highscore_file, "r") as f:
            for line in f:
                try:
                    highscores.append(int(line.strip()))
                except:
                    pass
    highscores.sort(reverse=True)
    highscores = highscores[:5]

    font = pygame.font.SysFont(None, 36)

    running = True
    game_over = False

    while running:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if not game_over and event.type == SPAWN_EVENT:
                enemy = Enemy(assets)
                all_sprites.add(enemy)
                enemy_group.add(enemy)

            if not game_over and event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    player.shoot(bullet_group, assets)
                if event.key == pygame.K_p:
                    # Pause
                    pause = True
                    while pause:
                        for e in pygame.event.get():
                            if e.type == pygame.QUIT:
                                pygame.quit()
                                sys.exit()
                            if e.type == pygame.KEYDOWN and e.key == pygame.K_p:
                                pause = False
                        screen.fill(BLACK)
                        pause_surf = font.render("PAUSE – Drücke P zum Weiterspielen", True, WHITE)
                        screen.blit(pause_surf, (WIDTH//2 - pause_surf.get_width()//2, HEIGHT//2))
                        pygame.display.flip()
                if event.key == pygame.K_ESCAPE:
                    running = False

        if not game_over:
            # -------------------------------------------------------------------
            #  Updates
            # -------------------------------------------------------------------
            all_sprites.update()

            # -------------------------------------------------------------------
            #  Hintergrund scrollen
            # -------------------------------------------------------------------
            x_bg -= 2
            if x_bg <= -bg_width:
                x_bg = 0

            # -------------------------------------------------------------------
            #  Kollision: Spieler-Schuss trifft Gegner
            # -------------------------------------------------------------------
            hits = pygame.sprite.groupcollide(enemy_group, bullet_group, True, True)
            for hit in hits:
                # Explosion und Sound (Soundaufrufe auskommentiert)
                # AssetsExplosion = assets["explosion_sprites"]
                # Explosion(hit.rect.center, AssetsExplosion, all_sprites)
                # assets["explosion_sound"].play()
                score += 100

                if random.random() < POWERUP_CHANCE:
                    kind = random.choice(["shield", "weapon"])
                    pu = PowerUp(hit.rect.centerx, hit.rect.centery, kind, assets)
                    all_sprites.add(pu)
                    powerup_group.add(pu)

            # -------------------------------------------------------------------
            #  Kollision: Gegner-Schuss trifft Spieler
            # -------------------------------------------------------------------
            hits2 = pygame.sprite.spritecollide(player, enemy_bullets, True, pygame.sprite.collide_rect)
            if hits2:
                player.lives -= 1
                if player.lives <= 0:
                    game_over = True
                    # assets["gameover_sound"].play()  # Soundeffekt auskommentiert
                    highscores.append(score)
                    highscores.sort(reverse=True)
                    highscores = highscores[:5]
                    with open(highscore_file, "w") as f:
                        for s in highscores:
                            f.write(f"{s}\n")

            # -------------------------------------------------------------------
            #  Kollision: Spieler nimmt Power-Up auf
            # -------------------------------------------------------------------
            pu_hits = pygame.sprite.spritecollide(player, powerup_group, False)
            for pu in pu_hits:
                pu.apply(player)

        # -------------------------------------------------------------------
        #  Draw / Render
        # -------------------------------------------------------------------
        screen.blit(bg_img, (x_bg, 0))
        screen.blit(bg_img, (x_bg + bg_width, 0))

        all_sprites.draw(screen)

        score_surf = font.render(f"Score: {score}", True, WHITE)
        screen.blit(score_surf, (10, 10))
        lives_surf = font.render(f"Leben: {player.lives}", True, WHITE)
        screen.blit(lives_surf, (WIDTH - 150, 10))

        # -------------------------------------------------------------------
        #  Game Over-Anzeige
        # -------------------------------------------------------------------
        if game_over:
            overlay = pygame.Surface((WIDTH, HEIGHT))
            overlay.set_alpha(180)
            overlay.fill((0, 0, 0))
            screen.blit(overlay, (0, 0))
            go_surf = font.render("GAME OVER", True, WHITE)
            score_surf2 = font.render(f"Dein Score: {score}", True, WHITE)
            hs_surf = font.render(f"Highscores: {highscores}", True, WHITE)
            tip_surf = font.render("Drücke R um neu zu starten oder ESC zum Beenden", True, WHITE)
            screen.blit(go_surf, (WIDTH//2 - go_surf.get_width()//2, HEIGHT//2 - 60))
            screen.blit(score_surf2, (WIDTH//2 - score_surf2.get_width()//2, HEIGHT//2 - 20))
            screen.blit(hs_surf, (WIDTH//2 - hs_surf.get_width()//2, HEIGHT//2 + 20))
            screen.blit(tip_surf, (WIDTH//2 - tip_surf.get_width()//2, HEIGHT//2 + 60))

            keys = pygame.key.get_pressed()
            if keys[pygame.K_r]:
                main()
            if keys[pygame.K_ESCAPE]:
                running = False

        pygame.display.flip()

    pygame.quit()
    sys.exit()

# -------------------------------------------------------------------
#  Explosion-Helper-Klasse (bleibt drin für den Fall, dass du später Frames hinzufügst)
# -------------------------------------------------------------------
class Explosion(pygame.sprite.Sprite):
    def __init__(self, center, explosion_sprites, all_sprites_group):
        super().__init__()
        self.explosion_sprites = explosion_sprites
        self.frame = 0
        if self.explosion_sprites:
            self.image = self.explosion_sprites[self.frame]
        else:
            self.image = pygame.Surface((0, 0))
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.last_update = pygame.time.get_ticks()
        self.frame_rate = 50  # ms pro Frame
        all_sprites_group.add(self)

    def update(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > self.frame_rate:
            self.last_update = now
            self.frame += 1
            if self.frame == len(self.explosion_sprites):
                self.kill()
            else:
                self.image = self.explosion_sprites[self.frame]
                self.rect = self.image.get_rect(center=self.rect.center)

# -------------------------------------------------------------------
#  Spiel starten
# -------------------------------------------------------------------
if __name__ == "__main__":
    main()
